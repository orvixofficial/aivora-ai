# Aivora AI — Personal Knowledge Chatbot

A beginner-friendly Next.js chatbot for GitHub + Vercel. It uses the OpenAI Responses API and optionally searches your own documents with File Search.

## 1. What you need

- A GitHub account
- A Vercel account
- An OpenAI API project and API key (API use may cost money)
- Node.js 20 or newer on your computer, or a cloud development environment such as GitHub Codespaces

## 2. Run locally

1. Download and unzip this project.
2. Open the project folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env.local`.
5. Put your API key in `.env.local`:

   `OPENAI_API_KEY=your_real_key_here`

6. Run `npm run dev`.
7. Open `http://localhost:3000`.

Never commit `.env.local` or share your API key.

## 3. Add your own documents

1. Put files you are allowed to use in `knowledge/`.
2. Make sure `.env.local` has your `OPENAI_API_KEY`.
3. Run `npm run index:knowledge`.
4. Wait for indexing to finish. Copy the printed vector store ID.
5. Add it to `.env.local`:

   `OPENAI_VECTOR_STORE_ID=vs_your_id_here`

6. Restart `npm run dev` and ask a question about the uploaded documents.

The indexing script uploads documents to your OpenAI API project. Do not upload private identity, health, financial, or other sensitive files. Re-running the starter indexing script creates a new vector store; it does not automatically append to an existing one.

## 4. Publish to GitHub

1. Create a new private GitHub repository named `aivora-personal-ai`.
2. Upload the project files and folders. Do not upload `.env.local`, API keys, or your private documents.
3. Check that `.gitignore` is included.
4. Commit the source files.

You can do this from the GitHub website or using Git. If you use Git locally:

```bash
git init
git add .
git commit -m "Create Aivora personal AI"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/aivora-personal-ai.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

## 5. Deploy to Vercel

1. Sign in to Vercel and choose **Add New → Project**.
2. Import your GitHub repository.
3. In Project Settings → Environment Variables, add:
   - `OPENAI_API_KEY` = your API key
   - `OPENAI_MODEL` = `gpt-4.1-mini` (or another model available to your API project)
   - `OPENAI_VECTOR_STORE_ID` = the vector store ID printed by the indexing script (optional until you index files)
4. Deploy or redeploy after adding environment variables.
5. Open the deployment URL and test the chat.

## 6. Cost control

- OpenAI API billing is separate from a ChatGPT subscription.
- Choose a low-cost model available to your project and keep replies short.
- File Search has separate tool-call and storage pricing; check current official pricing before uploading lots of documents.
- Set a usage budget/alerts in the API platform if available to your account, and regularly review Usage.
- Avoid enabling paid web search or other tools until you need them.
- Do not promise users unlimited free AI. A frontend can be free to host while model requests still cost money.

Official pricing: https://developers.openai.com/api/docs/pricing
File Search guide: https://developers.openai.com/api/docs/guides/tools-file-search

## 7. Security checklist before sharing publicly

This is a starter, not a fully hardened public service.

- Keep API keys only in server-side environment variables.
- Keep personal documents out of GitHub; this repo ignores the contents of `knowledge/`.
- Add authentication and robust rate limiting before making the app public. Without these, strangers could consume your API budget.
- Set spending alerts or usage limits where available.
- Review and remove uploaded files/vector stores you no longer need.
- Never put private information in public chatbot answers.
- Use only documents you own or have permission to upload.
- This starter does not save chat history in a database. Refreshing the page clears the conversation.
- The simple request length limit is not a substitute for authentication or rate limiting.

## 8. Troubleshooting

- **503 / missing API key:** Add `OPENAI_API_KEY` to `.env.local` locally or Vercel Environment Variables online.
- **401 / authentication error:** Check that the key is valid and belongs to the correct API project.
- **429 / quota or rate limit:** Check billing, usage, and project limits.
- **No document-based answers:** Confirm `OPENAI_VECTOR_STORE_ID` is set and the files finished indexing.
- **Deployment did not update:** Redeploy after changing environment variables.
