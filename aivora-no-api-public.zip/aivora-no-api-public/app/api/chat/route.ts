import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(request: Request) {
  const backend = process.env.BACKEND_URL;
  const secret = process.env.BACKEND_SHARED_SECRET;
  if (!backend || !secret) {
    return NextResponse.json({ error: "Aivora backend is not configured." }, { status: 503 });
  }

  let body: unknown;
  try { body = await request.json(); }
  catch { return NextResponse.json({ error: "Invalid JSON." }, { status: 400 }); }

  const message = (body as { message?: unknown })?.message;
  if (typeof message !== "string" || !message.trim() || message.length > 2000) {
    return NextResponse.json({ error: "Enter a message up to 2,000 characters." }, { status: 400 });
  }

  try {
    const response = await fetch(`${backend.replace(/\\/$/, "")}/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${secret}`,
        // Forward a request IP hint for the starter limiter; production needs a trusted durable limiter.
        "X-Forwarded-For": request.headers.get("x-forwarded-for") || "unknown"
      },
      body: JSON.stringify({ message: message.trim() }),
      signal: AbortSignal.timeout(55000),
      cache: "no-store"
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      return NextResponse.json({ error: data.detail || "The AI backend is unavailable." }, { status: response.status === 429 ? 429 : 502 });
    }
    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ error: "Cannot reach the AI server. Check that the backend and HTTPS tunnel are running." }, { status: 502 });
  }
}
