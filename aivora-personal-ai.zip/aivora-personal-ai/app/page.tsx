 "use client";

import { FormEvent, useState } from "react";

type Message = { role: "user" | "assistant"; content: string };

const suggestions = [
  "Tell me about Riyan's projects.",
  "What do you know from my documents?",
  "Help me plan a technology startup."
];

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hello! I’m Aivora AI. Ask me about Riyan’s projects, ideas, or the documents connected to this assistant." }
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function send(text = input) {
    const question = text.trim();
    if (!question || busy) return;
    setError("");
    setMessages((old) => [...old, { role: "user", content: question }]);
    setInput("");
    setBusy(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: question })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "The request failed.");
      setMessages((old) => [...old, { role: "assistant", content: data.reply || "I could not generate a response." }]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not connect. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    void send();
  }

  return (
    <main className="shell">
      <header className="topbar">
        <div className="brand-mark">A</div>
        <div>
          <div className="brand-name">Aivora <span>AI</span></div>
          <div className="brand-subtitle">YOUR PERSONAL KNOWLEDGE ASSISTANT</div>
        </div>
        <div className="status"><i /> Ready to chat</div>
      </header>

      <section className="hero">
        <div className="eyebrow">PERSONAL AI · BUILT AROUND YOUR KNOWLEDGE</div>
        <h1>Ideas become clearer<br /><span>with Aivora.</span></h1>
        <p>Ask questions, explore your projects, and get help finding information in your own documents.</p>
      </section>

      <section className="chat-card" aria-label="Chat with Aivora AI">
        <div className="chat-heading">
          <div className="avatar">A</div>
          <div><strong>Aivora Assistant</strong><small>Answers based on profile context and connected files</small></div>
        </div>
        <div className="messages" aria-live="polite">
          {messages.map((m, i) => (
            <div key={i} className={`message-row ${m.role}`}>
              {m.role === "assistant" && <div className="mini-avatar">A</div>}
              <div className="bubble">{m.content}</div>
            </div>
          ))}
          {busy && <div className="message-row assistant"><div className="mini-avatar">A</div><div className="bubble typing">Thinking…</div></div>}
        </div>
        {messages.length <= 1 && <div className="suggestions">
          {suggestions.map((s) => <button type="button" key={s} onClick={() => void send(s)}>{s}<span>↗</span></button>)}
        </div>}
        {error && <p className="error" role="alert">{error}</p>}
        <form className="composer" onSubmit={onSubmit}>
          <input value={input} onChange={(e) => setInput(e.target.value)} maxLength={4000} placeholder="Ask Aivora anything…" aria-label="Your message" />
          <button className="send-button" disabled={busy || !input.trim()} aria-label="Send message" type="submit">↑</button>
        </form>
        <div className="privacy-note">Do not share passwords, payment details, or sensitive personal information.</div>
      </section>
      <footer>Built for curious minds · <span>Aivora AI</span></footer>
    </main>
  );
}
