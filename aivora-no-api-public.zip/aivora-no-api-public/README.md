# Aivora AI — No paid model API starter

This starter uses:
- Next.js frontend + server-side proxy (deploy the website on Vercel if its plan fits your use)
- FastAPI backend running on a machine you control
- Ollama local models (no OpenAI/Gemini inference API)
- Public knowledge documents in `backend/knowledge/`
- Local embeddings + cosine similarity for basic RAG

## Important reality check

This is a prototype, not a many-user production system. A truly free, always-on service with many simultaneous users is not a realistic guarantee: inference needs CPU/GPU/RAM and bandwidth. For a free trial, run the backend on your own computer and keep it on, or use any free compute you already have. The public website will only answer while that machine is reachable. For reliable launch traffic, budget for a server or obtain sponsored compute.

The included basic rate limiter is process-local and is not sufficient for a large public launch. Before inviting many users, add a durable shared rate limiter, authentication/abuse protection, monitoring, queueing, backups, and load testing. Vercel Hobby is documented for personal, non-commercial use; check the current plan terms before using it for a commercial brand.

## Architecture

Browser -> Vercel Next.js `/api/chat` -> private FastAPI backend -> Ollama local model
                                                -> public document index

The browser never receives the backend shared secret. Do not expose Ollama port 11434 publicly. Expose only FastAPI through a protected HTTPS tunnel or reverse proxy.

## 1. Requirements

- Node.js 20+
- Python 3.11+
- Ollama installed on the backend machine
- Internet for downloading packages/models the first time
- About 4–8 GB RAM for a small quantized model; more RAM improves comfort. `qwen2.5:3b` download is roughly 2 GB, but runtime memory needs additional headroom.

## 2. Start the local model

Install Ollama from its official site, then run:

```bash
ollama pull qwen2.5:3b
ollama pull nomic-embed-text
ollama serve
```

On some systems Ollama is already running as a service; if so, don't start a second server. Keep Ollama bound to localhost; don't expose port 11434 to the public internet.

## 3. Backend setup

Open a terminal in `backend/`:

```bash
python -m venv .venv
```

Activate it:
- Windows PowerShell: `.venv\\Scripts\\Activate.ps1`
- macOS/Linux: `source .venv/bin/activate`

Then:

```bash
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and set a long random `BACKEND_SHARED_SECRET`. Keep this secret private. Add public/approved reference documents to `backend/knowledge/` as `.txt`, `.md`, or `.pdf`. Only add documents you have permission to publish; this is a shared public knowledge base.

Run the backend:

```bash
uvicorn app:app --host 127.0.0.1 --port 8000
```

The first start indexes the documents with `nomic-embed-text`. That can take a while. The index is stored in `backend/index.json`; don't commit the index if it contains content you don't intend to publish.

Check locally:
`http://127.0.0.1:8000/health`

## 4. Expose the backend safely for a trial

For a local-only test, don't expose it at all. For a public trial, use a trusted HTTPS tunnel/reverse proxy that targets `http://127.0.0.1:8000`. Configure its hostname as `BACKEND_URL` in the Vercel project.

Security rules:
- Do NOT tunnel or publish port 11434 (Ollama).
- Only the FastAPI backend should be reachable through the tunnel.
- Keep `BACKEND_SHARED_SECRET` set in backend `.env` and the same value in Vercel environment variables.
- Use HTTPS.
- Stop the tunnel when you are not testing.
- A shared secret is a starter gate, not a replacement for a proper identity system and durable rate limiting.

## 5. Deploy the website

1. Create a GitHub repository and upload the project, excluding all `.env` files, `.venv`, local documents, and secrets.
2. Import the repository into Vercel.
3. Set Vercel environment variables:
   - `BACKEND_URL` = your HTTPS FastAPI URL, no trailing slash
   - `BACKEND_SHARED_SECRET` = same random secret as backend `.env`
4. Deploy and test the website.

Vercel serverless functions cannot reach `localhost` on your home computer. `BACKEND_URL` must be a reachable HTTPS endpoint. The website does not magically host the model.

## 6. Add public documents

Place `.txt`, `.md`, or `.pdf` files in `backend/knowledge/`, then restart FastAPI. It re-builds an in-memory embedding index at startup and saves `index.json`. For this starter, restarting the backend is how you refresh the index.

Use only public/approved documents. Uploaded documents are not implemented in this starter; this is a shared admin-managed knowledge base. Do not add secrets, student records, private chats, or personal data.

## 7. Production before many users

Do not announce unlimited access on the prototype. Add:
- Redis/managed durable rate limiting (the in-memory limit resets on restart and differs across workers)
- Login or a bot-challenge before costly requests
- Request queue and concurrency caps
- Persistent vector database/index with backups
- Monitoring, alerts, model health checks
- File provenance/citations and document-update workflow
- Abuse reporting and clear privacy policy
- A stronger server/GPU plan sized from load tests

## Costs

- Model API calls: $0 in this design (the model runs on your machine/server).
- GitHub: source hosting can be free.
- Vercel: free Hobby is intended for personal, non-commercial projects and has usage limits; verify terms and quotas.
- Home-hosted trial: no extra compute rental, but uses electricity, internet, your hardware, and uptime.
- Reliable public service: usually needs paid compute or sponsored hardware. "Free-only + many simultaneous users + always on" cannot be promised.

## Troubleshooting

- `401`: backend and Vercel shared secrets don't match.
- `502`: backend URL is wrong, tunnel is down, or FastAPI is not running.
- `Ollama connection error`: start Ollama and check `http://127.0.0.1:11434`.
- Slow answers: use a smaller model, reduce retrieved context, limit simultaneous requests, or use stronger hardware.
- No useful document answers: add text-rich documents, restart the backend, and test with questions that match the content.
