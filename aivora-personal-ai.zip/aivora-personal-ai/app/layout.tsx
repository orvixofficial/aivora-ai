import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Aivora AI — Personal Assistant",
  description: "A personal AI assistant for Riyan, powered by your own documents."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
