import OpenAI from "openai";
import fs from "node:fs/promises";
import path from "node:path";

const key = process.env.OPENAI_API_KEY;
if (!key) {
  console.error("Missing OPENAI_API_KEY. Add it to .env.local before running this script.");
  process.exit(1);
}

const folder = path.resolve("knowledge");
const allowed = new Set([".pdf", ".docx", ".txt", ".md", ".html", ".json", ".pptx", ".py", ".js", ".ts", ".csv"]);
const entries = await fs.readdir(folder, { withFileTypes: true }).catch(() => []);
const paths = entries
  .filter((entry) => entry.isFile() && entry.name.toLowerCase() !== "readme.md" && allowed.has(path.extname(entry.name).toLowerCase()))
  .map((entry) => path.join(folder, entry.name));

if (paths.length === 0) {
  console.error("No supported documents found in ./knowledge. Add files and run this command again.");
  process.exit(1);
}

const client = new OpenAI({ apiKey: key });
const store = await client.vectorStores.create({ name: "Aivora Riyan Personal Knowledge" });
console.log(`Created vector store: ${store.id}`);

for (const filePath of paths) {
  console.log(`Uploading and indexing ${path.basename(filePath)} ...`);
  const uploaded = await client.files.create({
    file: await fs.open(filePath).then((handle) => handle.createReadStream()),
    purpose: "assistants"
  });
  await client.vectorStores.files.createAndPoll(store.id, uploaded.id);
  console.log(`Indexed: ${path.basename(filePath)}`);
}

console.log("\nDone. Copy this ID into OPENAI_VECTOR_STORE_ID in .env.local and Vercel:");
console.log(store.id);
console.log("\nKeep this ID and your API key private. To add more documents later, rerun with a new store or extend this script to reuse an existing store.");
