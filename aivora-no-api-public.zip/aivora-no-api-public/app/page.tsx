 "use client";

import { FormEvent, useState } from "react";
type Message = { role: "user" | "assistant"; content: string; sources?: string[] };

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hi! I’m Aivora AI. Ask a question about the public knowledge base. I’ll use the local AI model and available documents." }
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function send(e?: FormEvent) {
    e?.preventDefault();
    const message = input.trim();
    if (!message || busy) return;
    setInput("");
    setError("");
    setMessages(prev => [...prev, { role: "user", content: message }]);
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed");
      setMessages(prev => [...prev, { role: "assistant", content: data.answer, sources: data.sources || [] }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not reach Aivora.");
    } finally {
      setBusy(false);
    }
  }

  return <main className="shell">
    <header className="topbar">
      <div className="logo">A</div>
      <div><b>Aivora <span>AI</span></b><small>LOCAL MODEL · PUBLIC KNOWLEDGE</small></div>
      <div className="online"><i /> Prototype</div>
    </header>
    <section className="hero">
      <p className="eyebrow">NO PAID MODEL API</p>
      <h1>Ask anything.<br /><span>Learn from knowledge.</span></h1>
      <p className="sub">Aivora finds relevant passages from its shared knowledge base and uses a locally hosted language model to draft an answer.</p>
    </section>
    <section className="panel">
      <div className="panel-head"><div className="assistant-icon">A</div><div><b>Aivora Assistant</b><small>Answers may be wrong; check sources for important facts.</small></div></div>
      <div className="messages" aria-live="polite">
        {messages.map((m, i) => <div className={`line ${m.role}`} key={i}>
          {m.role === "assistant" && <div className="tiny-logo">A</div>}
          <div className="bubble">{m.content}
            {m.sources?.length ? <div className="sources"><b>Sources</b>{m.sources.map((s, n) => <div key={n}>• {s}</div>)}</div> : null}
          </div>
        </div>)}
        {busy && <div className="line assistant"><div className="tiny-logo">A</div><div className="bubble muted">Reading knowledge and thinking…</div></div>}
      </div>
      {error && <div className="error">{error}</div>}
      <form className="composer" onSubmit={send}>
        <input value={input} onChange={e => setInput(e.target.value)} maxLength={2000} placeholder="Ask about the public knowledge base…" />
        <button disabled={busy || !input.trim()} type="submit" aria-label="Send">↑</button>
      </form>
      <p className="disclaimer">Public demo. Don’t submit passwords, private documents, or sensitive personal information.</p>
    </section>
    <footer>Aivora AI · Open models, your own infrastructure</footer>
  </main>;
}
