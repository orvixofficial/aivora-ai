Backend notes:
- Ollama must be running on the same machine or on a private network.
- Never expose Ollama port 11434 directly to the internet.
- Public documents are read at startup; restart FastAPI to refresh the index.
- The current in-memory rate limiter is only a prototype. It resets on restart and does not coordinate across workers.
