Put only public or approved .txt, .md, or .pdf reference documents in this folder.
Do not put private records, passwords, or confidential material here.
Restart the backend after adding/updating documents so the index refreshes.
