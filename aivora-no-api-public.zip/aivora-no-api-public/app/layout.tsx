import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Aivora AI",
  description: "Aivora AI — a document-grounded assistant running on local open models."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
