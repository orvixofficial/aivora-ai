# Your private knowledge files

Place documents you are allowed to use in this folder before running `npm run index:knowledge`.

Supported by this starter script: PDF, DOCX, TXT, Markdown, HTML, JSON, PPTX, Python, JavaScript, TypeScript, and CSV.

Important:
- Do not put passwords, identity documents, financial account details, or other sensitive files here.
- The indexing script uploads the documents to your OpenAI API project for file search.
- This starter creates a new vector store when run. Save the ID it prints.
- Files are not uploaded just because they are in this folder; you must run the indexing command.
- `.gitignore` prevents your knowledge files from being committed to GitHub.
